
import React, { useState } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import UserManagement from './pages/UserManagement';
import ReportModeration from './pages/ReportModeration';
import ContentManagement from './pages/ContentManagement';
import Blacklist from './pages/Blacklist';

const App: React.FC = () => {
  return (
    <HashRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/users" element={<UserManagement />} />
          <Route path="/blacklist" element={<Blacklist />} />
          <Route path="/reports" element={<ReportModeration />} />
          <Route path="/content" element={<ContentManagement />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </HashRouter>
  );
};

export default App;
